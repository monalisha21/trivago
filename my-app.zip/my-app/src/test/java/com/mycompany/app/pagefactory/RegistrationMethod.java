package com.mycompany.app.pagefactory;

import org.openqa.selenium.WebDriver;

import com.mycompany.app.helper.PageInfra;

public class RegistrationMethod extends PageInfra {

	public RegistrationMethod(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
