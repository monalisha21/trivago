package com.mycompany.app.helper;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.browserstack.local.Local;
import com.mycompany.app.helper.JsonHelper;

public class TestSetUp {
	private RemoteWebDriver driver;
	private ResourceBundle bundle;
	Local bsLocal = new Local();
	private String localId;
	private String imageName;
	private JsonHelper jsonHelper;
	private static String exactFileName;
	private static String getVersion = "/vcf-center/api/application";
	private static String getRestApi = "/vRest/admin-services";
	private static final Logger log = Logger.getLogger(TestSetUp.class);
	
	private static int SESSION_TIMEOUT = 300;
	@Parameters({ "url", "browser", "local", "bsUserId", "bsKey", "jenkins" })
	@BeforeClass(alwaysRun = true)
	public void initDriver(String url, String browser, @Optional("0") String local, String bsUserId, String bsKey,
			@Optional("0") String jenkins) throws Exception {
		if (Integer.parseInt(local) == 1) {
			startDriver(url, browser);
		} else {
			startDriver(url, browser, bsUserId, bsKey, Integer.parseInt(jenkins));
		}
	}

	public void startDriver(String url, String browserName) {
		String os = System.getProperty("os.name").toLowerCase();
		String chrDriver = null;

		if (os.contains("win")) {
			chrDriver = "src/test/resources/chromedriver_win.exe";
		} else if (os.contains("mac")) {
			chrDriver = "src/test/resources/chromedriver_mac";
		} else if (os.contains("linux")) {
			chrDriver = "src/test/resources/chromedriver_linux64";
		}

		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", chrDriver);
			DesiredCapabilities chromeCaps = DesiredCapabilities.chrome();
			chromeCaps.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
			chromeCaps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			driver = new ChromeDriver(chromeCaps);
			driver.manage().timeouts().implicitlyWait(SESSION_TIMEOUT, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get("https:" + url);
		} else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "src/test/resources/geckodriver");
			DesiredCapabilities caps = DesiredCapabilities.firefox();
			caps.setCapability("marionette", true);
			caps.setCapability("acceptInsecureCerts", true);
			// var capabilities = new FirefoxOptions().addTo(caps);
			driver = new FirefoxDriver(caps);
			driver.get("https://" + url);
		}
		// TODO: ADD Firefox, IE AND SAFARI TO THE LIST
	}

	public void startDriver(String url, String browser, String bsUserId, String bsKey, int jenkins) throws Exception {
		String sessionId = null;
		String command = null;
		HashMap<String, String> bsLocalArgs = new HashMap<String, String>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
		String dateAsString = simpleDateFormat.format(new Date());
		String localId = "convergenceTest" + dateAsString;
		if (jenkins == 0) {
			bsLocalArgs.put("localIdentifier", localId); // environment variable
			bsLocalArgs.put("key", bsKey); // BrowserStack Key
			bsLocalArgs.put("v", "true");
			bsLocal.start(bsLocalArgs);
		}

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("browser", browser);
		caps.setCapability("build", "VCFC SmokeTest Cases");
		caps.setCapability("acceptSslCerts", "true");
		caps.setCapability("acceptInsecureCerts", true);
		caps.setCapability("browserstack.debug", "true");
		caps.setCapability("browserstack.idleTimeout", "150");
	    //caps.setCapability("platform", "ANY");
		caps.setCapability("os", "Windows");
		caps.setCapability("os_version", "10");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("browserstack.console", "verbose");
		if (browser.equalsIgnoreCase("firefox")) {
			FirefoxProfile firefoxProfile = new FirefoxProfile();
			firefoxProfile.setPreference("security.tls.insecure_fallback_hosts", false);
			firefoxProfile.setAcceptUntrustedCertificates(true);
			caps.setCapability(FirefoxDriver.PROFILE, firefoxProfile);
			caps.setCapability("browser_version", "54");
		}
		if (browser.equalsIgnoreCase("chrome")) {
			caps.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
		}
		if (jenkins == 0) {
			caps.setCapability("browserstack.local", "true");
			caps.setCapability("browserstack.localIdentifier", localId);
		} else {
			String browserstackLocal = System.getenv("BROWSERSTACK_LOCAL");
			String browserstackLocalIdentifier = System.getenv("BROWSERSTACK_LOCAL_IDENTIFIER");
			caps.setCapability("browserstack.local", browserstackLocal);
			caps.setCapability("browserstack.localIdentifier", browserstackLocalIdentifier);
		}
		driver = new RemoteWebDriver(
				new URL("https://" + bsUserId + ":" + bsKey + "@hub-cloud.browserstack.com/wd/hub"), caps);
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		// Get a handle to the driver.
		try {
			driver.get("https://" + url);
		} catch (Exception e) {
			log.error("Unable to open connection to " + url);
		}
		log.info("Browserstack logs:"+getBSLogs(bsUserId, bsKey));
	}

	/*
	 * This method is invoked when a browserstack session is created to retrieve
	 * and print out link to the logs in the console output.
	 *
	 */
	public String getBSLogs(String bsUserId, String bsKey) {
		String publicUrl = null;
		jsonHelper = new JsonHelper();
		String sessId = driver.getSessionId().toString();
		String request = "/automate/sessions/"+sessId+".json";
		HashMap httpJson = new HashMap();

		do {
			httpJson = jsonHelper.getBrowserStackHttpResult("browserstack.com", request, bsUserId, bsKey);
		} while(!httpJson.get("status").toString().equals("200"));

		if (httpJson.get("status").toString().equals("200")) {
			JSONObject jsonObject = new JSONObject(httpJson.get("data").toString());
			publicUrl = jsonObject.get("public_url").toString();
		}
		return publicUrl;
	}

	@Parameters({ "jenkins", "url" })
	@AfterClass(alwaysRun = true)
	public void setupAfterSuite(@Optional("0") String jenkins, String url) {
		log.info("Cleaning up session after testclass");
		try {
			driver.quit();
			if (Integer.parseInt(jenkins) == 0) {
				bsLocal.stop();
			}
		} catch (Exception e) {
			log.error("Driver already closed");
		}
	}
}
