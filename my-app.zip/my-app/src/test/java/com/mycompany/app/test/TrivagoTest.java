package com.mycompany.app.test;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.mycompany.app.helper.TestSetUp;


public class TrivagoTest extends TestSetUp {
	private static final Logger log = Logger.getLogger(TrivagoTest.class);
	@Parameters({ "url" })
	@BeforeClass(alwaysRun = true)
	public void init(String url) throws Exception {
		

	}

}
