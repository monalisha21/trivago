package com.mycompany.app.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageInfra {
	protected WebDriver driver;
	protected ResourceBundle rb;
	protected Select select;
	private static final Logger log = Logger.getLogger(PageInfra.class);
	private static final int ELEMENT_WAIT_TIMEOUT = 100;
	private static final int SHORT_ELEMENT_WAIT_TIMEOUT = 10;
	private static final String fileUploadsStatus = "COMPLETED";

	public PageInfra(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void setValue(WebElement field, String strUserName) {
		field.clear();
		field.sendKeys(strUserName);
	}

	public void setValue(WebElement field, String value, Keys key) {
		if (field.getTagName().equalsIgnoreCase("input")) {
			field.clear();
		}
		field.sendKeys(value, key);
	}

	public void setValue(By by, String value, Keys key) {
		setValue(driver.findElement(by), value, key);
	}

	public void setValue(By by, String value) {
		setValue(driver.findElement(by), value);
	}

	public void sendKeysToElement(By by, Keys key) {
		driver.findElement(by).sendKeys(key);
	}

	public void selectElement(By locator, String value) {
		WebElement webElem = driver.findElement(locator);
		selectElement(webElem, value);
	}

	public void selectElement(WebElement field, String value) {
		Select mySelect = new Select(field);
		boolean multiSelect = mySelect.isMultiple();
		if ((multiSelect == false) || (!value.contains(","))) {
			mySelect.selectByVisibleText(value);
		} else {
			String multipleValues[] = value.split(",");
			for (String valueToBeSelected : multipleValues) {
				mySelect.selectByVisibleText(valueToBeSelected);
			}
		}
	}

	public void moveToElements(WebElement field, WebElement field2) {
		Actions builder = new Actions(driver);
		waitForElementVisibility(field);
		builder.moveToElement(field).moveToElement(field2).build().perform();
	}

	public void moveToWebElement(By byPath) {
		WebElement webElement = driver.findElement(byPath);
		new Actions(driver).moveToElement(webElement).perform();
	}

	public void textToBePresentInElement(final String locator) {
		(new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return driver.findElement(By.tagName(locator)).getText().length() != 0;
			}
		});
	}

	public void textToBePresentInElementValue(By locator, String Text) {
		(new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT))
				.until(ExpectedConditions.textToBePresentInElementValue(locator, Text));
	}

	// Replace substring until delimiter in originalString by replacementString
	public String replaceSubstring(String originalString, char delimCharacter, String replacementString) {

		int endIndex = originalString.indexOf(delimCharacter) + 1;

		return originalString.replace(originalString.substring(0, endIndex), replacementString);

	}

	public void setElementAttribute(WebElement element, String attribute, String attributeValue) {
		((JavascriptExecutor) driver)
				.executeScript("arguments[0].setAttribute('" + attribute + "', '" + attributeValue + "')", element);
	}

	public boolean fileUploadsForNonInputElements(String[] fileNameList) throws InterruptedException {
		boolean allFileUploadStatus = true;
		try {
			((JavascriptExecutor) driver).executeScript(
					"HTMLInputElement.prototype.click = function() {if(this.type !== 'file') HTMLElement.prototype.click.call(this);};");
			List<WebElement> fileUploadsList;
			if (driver.findElements(By.xpath("//*[contains(text() , 'Upload')]")).size() != 0) {
				fileUploadsList = driver.findElements(By.xpath("//*[contains(text() , 'Upload')]"));
			} else {
				fileUploadsList = driver.findElements(By.xpath("//button[text() ='Choose File ']"));
			}
			for (int i = 0; i < fileUploadsList.size(); i++) {
				WebElement element = driver.findElement(By.xpath("(//input[@type='file'])[" + (i + 1) + "]"));
				String fileUploadProgressStatus = "(//span[@class='progress-status'])[" + (i + 1) + "]";
				if (fileUploadsList.get(i).isDisplayed()) {
					if (!uploadFile(element, fileUploadProgressStatus, fileNameList[i])) {
						allFileUploadStatus = false;
					}
				}
			}
		} catch (Exception e) {
			log.error(e);
			allFileUploadStatus = false;
		}
		return allFileUploadStatus;
	}

	public boolean textToBePresent(By locator) {
		return (new WebDriverWait(driver, SHORT_ELEMENT_WAIT_TIMEOUT)
				.until(ExpectedConditions.textToBePresentInElementLocated(locator, fileUploadsStatus)));
	}

	public boolean uploadFile(WebElement element, String fileUploadProgressStatus, String fileName) {
		boolean singleFileUploadStatus = true;
		if (driver instanceof RemoteWebDriver) {
			((RemoteWebElement) element).setFileDetector(new LocalFileDetector());
			element.sendKeys(fileName);
		} else {
			element.sendKeys(FileSystems.getDefault().getPath(fileName).normalize().toAbsolutePath().toString());
		}
		if (!textToBePresent(By.xpath(fileUploadProgressStatus))) {
			singleFileUploadStatus = false;
		}
		return singleFileUploadStatus;
	}

	public void frameToBeAvailable(By locator) {
		(new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT))
				.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));
	}

	public void clickOnElements(WebElement field, WebElement field2) {
		Actions builder = new Actions(driver);
		waitForElementVisibility(field);
		builder.moveToElement(field).click(field2).build().perform();
	}

	public void waitForElementPresent(By locator) {
		(new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT)).until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public boolean waitForElementStaleUp(WebElement el) {
		return (new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT)).until(ExpectedConditions.stalenessOf(el));
	}

	public WebElement waitForElementVisibility(WebElement el) {
		return (new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(el));
	}

	public WebElement waitForElementVisibilityLocatedBy(WebElement el) {
		return (new WebDriverWait(driver, SHORT_ELEMENT_WAIT_TIMEOUT)).until(ExpectedConditions.visibilityOf(el));
	}

	public boolean waitForInvisibilityOfElementLocated(final By locator) {
		return (new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT))
				.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	public WebElement waitForVisibilityOfElementLocated(final By locator) {
		return (new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT))
				.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public WebElement waitForElementToClick(final By locator) {
		return (new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT))
				.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public WebElement waitForElementToClick(WebElement el) {
		return (new WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT)).until(ExpectedConditions.elementToBeClickable(el));
	}

	public boolean retryingFindClick(By by) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 10) {
			try {
				boolean exists = (driver.findElements(by)).size() != 0;
				if (exists) {
					driver.findElement(by).click();
					result = true;
					break;
				} else {
					// WebDriver wait = new WebDriverWait(driver,30);
				}
			} catch (Exception e) {
			}
			attempts++;
		}
		return result;
	}

	public boolean retryingFindClick(WebElement el) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 10) {
			try {
				el.click();
				result = true;
				break;
			} catch (Exception e) {
			}
			attempts++;
		}
		return result;
	}

	public boolean retryingFindClick(WebElement el, By by) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 10) {
			try {
				el.findElement(by).click();
				result = true;
				break;
			} catch (Exception e) {
			}
			attempts++;
		}
		return result;
	}

	public ExpectedCondition<WebElement> visibilityOfElementLocated(final By locator) {
		return new ExpectedCondition<WebElement>() {
			public WebElement apply(WebDriver driver) {
				WebElement toReturn = driver.findElement(locator);
				if (toReturn.isDisplayed()) {
					return toReturn;
				}
				return null;
			}
		};
	}

	public ResourceBundle getBundle() {
		return rb;
	}

	public boolean isElementActive(By by) {
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
		boolean exists = (driver.findElements(by).size() != 0);

		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		return exists;
	}

	// Common Method use to click on any web element. Just Pass By Object
	public boolean clickOnWebElement(By byPath) {
		try {
			WebElement webElement = driver.findElement(byPath);
			clickOnWebElement(webElement);
		} catch (Exception e) {
			log.error(e);
			return false;
		}
		return true;
	}

	public boolean clickOnWebElement(WebElement webElement) {
		try {
			waitForElementVisibility(webElement);
			webElement.click();
		} catch (StaleElementReferenceException e) {
		} catch (Exception e) {
			log.error(e);
			return false;
		}
		return true;
	}

	// Common Method use to click on any web element. Just Pass By Object
	public boolean hoverOnWebElement(By byPath) {
		try {
			WebElement webElement = driver.findElement(byPath);
			waitForElementVisibility(webElement);
			new Actions(driver).moveToElement(webElement).perform();
			return true;
		} catch (Exception e) {
			log.error(e);
			return false;
		}
	}

	// Common Method to input text into web element. Just Pass By Object
	public boolean enterTextWebElement(By byPath, String text) {
		try {
			WebElement webElement = driver.findElement(byPath);
			waitForElementVisibility(webElement);
			webElement.sendKeys(text);
			return true;
		} catch (Exception e) {
			log.error(e);
			return false;
		}
	}

	public WebElement findElementByText(String htmlTagName, String text) {
		WebElement webElement = null;
		try {
			String htmlXpath = "//" + htmlTagName + "[contains(.,'" + text + "')]";
			waitForElementToClick(By.xpath(htmlXpath));
			webElement = driver.findElement(By.xpath(htmlXpath));
		} catch (Exception e) {
			log.error(e);
		}
		return webElement;
	}

	public List<WebElement> findElementsByText(By locator) {
		return driver.findElements(locator);
	}

	public boolean selectDropDownValue(By byPathDownArrow, By byDropDownList, String menuItemSelector, String value) {
		boolean status = true;
		try {
			waitForVisibilityOfElementLocated(byPathDownArrow);
			WebElement downArrow = driver.findElement(byPathDownArrow);
			downArrow.click();
			findElementByText(menuItemSelector, value).click();
		} catch (Exception e) {
			log.error(e);
			status = false;
		}
		return status;
	}

	public String getAttributeValue(final By locator, String attribName) {
		String attribValue = driver.findElement(locator).getAttribute(attribName);
		return getAttributeValue(driver.findElement(locator), attribName);
	}

	public String getAttributeValue(WebElement webElem, String attribName) {
		return webElem.getAttribute(attribName);
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	// To get Switch Details
	public static List<Map<String, Object>> getSwitchDetailFromHostFile(String hostFile) throws IOException {
		List<Map<String, Object>> hostSwitchDetails = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> spineSwitch = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> leafSwitch = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> thirdPartySwitch = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> normalSwitch = new LinkedList<Map<String, Object>>();
		try (BufferedReader br = new BufferedReader(new FileReader(new File(hostFile)));) {
			String line = null;
			String switchType = null;
			while ((line = br.readLine()) != null) {
				line = line.trim();
				Pattern pattern = Pattern.compile("(\\[)(.*)(\\])");
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					switchType = matcher.group(2);
				}
				Map<String, Object> switchMap = parseStringIntoSwitchDetail(line, switchType);
				if (switchMap == null || switchMap.isEmpty()) {
					continue;
				}
				if (("spine").equalsIgnoreCase(switchType)) {
					spineSwitch.add(switchMap);
				} else if (("leaf").equalsIgnoreCase(switchType)) {
					leafSwitch.add(switchMap);
				} else if (("third_party_spine").equalsIgnoreCase(switchType)) {
					thirdPartySwitch.add(switchMap);
				} else if (("switch").equalsIgnoreCase(switchType)) {
					normalSwitch.add(switchMap);
				}
			}
			hostSwitchDetails.addAll(spineSwitch);
			hostSwitchDetails.addAll(leafSwitch);
			hostSwitchDetails.addAll(thirdPartySwitch);
			hostSwitchDetails.addAll(normalSwitch);
		}
		return hostSwitchDetails;
	}

	public static Map<String, Object> parseStringIntoSwitchDetail(String line, String switchType) {
		Map<String, Object> switchMap = null;
		if (line.trim().length() > 0 && !line.startsWith("#") && !line.matches("\\[.*\\]")) {
			switchMap = new LinkedHashMap<String, Object>();
			String[] splitLine = line.split(" ");
			switchMap.put("switchName", splitLine[0]);
			switchMap.put("host", splitLine[1].split("=")[1]);
			switchMap.put("switchType", switchType);
		}
		return switchMap;
	}

	public String retryingFindGetText(By by, int max_attempts) {
		String result = "0";
		int attempts = 0;
		while (attempts < max_attempts) {
			try {
				result = driver.findElement(by).getText();
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}
		return result;
	}

	public static boolean filesInventoryCheck(File fileName) {
		if (fileName.exists()) {
			return true;
		}
		return false;
	}

	public boolean stringNotNull(String testFields) {
		boolean status = true;
		if (testFields == null) {
			status = false;
		}
		return status;
	}

	public String captureSuccessMessage(By by) {
		waitForVisibilityOfElementLocated(by);
		String text = driver.findElement(by).getText();
		waitForInvisibilityOfElementLocated(by);
		return text;
	}

	public void switchToParent() {
		driver.switchTo().defaultContent();
	}

	public String[] readTextFile(String configFile) throws Exception {
		try {
			BufferedReader br = new BufferedReader(new FileReader(configFile));

			Map<String, String> map = new LinkedHashMap<String, String>();

			String line;
			String[] values;

			while (((line = br.readLine()) != null)) {
				values = line.split("=");
				String inputField = values[0];
				String inputValue = values[1];

				map.put(inputField, inputValue);
			}
			String[] inputValues = map.values().toArray(new String[0]);
			return (inputValues);

		} catch (FileNotFoundException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		}
	}

	

	public String execTerminalCmd(String command) {
		String[] cmd = new String[] { "bash", "-c", command };
		StringBuilder outputBuffer = new StringBuilder();
		ProcessBuilder proc = new ProcessBuilder(cmd);

		try {
			Process p2 = proc.start();
			InputStream commandOutput = p2.getInputStream();
			int readByte = commandOutput.read();

			while (readByte != 0xffffffff) {
				outputBuffer.append((char) readByte);
				readByte = commandOutput.read();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
			return null;
		}
		return outputBuffer.toString();

	}

	public int pcapTerminalCount(String filePath) {
		String fileName = FileSystems.getDefault().getPath(filePath).normalize().toAbsolutePath().toString();
		String command = "tshark -r " + fileName + " | wc -l";
		int terminalCount = 0;
		try {
			terminalCount = Integer.parseInt(execTerminalCmd(command).trim());
			log.info("Terminal Package Count is " + terminalCount);

		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
		}
		return (terminalCount);
	}

	public HashMap pcapTerminalCount(String filePath, String[] protocolType) {
		String fileName = FileSystems.getDefault().getPath(filePath).normalize().toAbsolutePath().toString();
		HashMap<String, Integer> hmap = new HashMap<String, Integer>();
		int terminalCount = 0;
		String command = "tshark -r " + fileName + " | wc -l";
		for (int i = 0; i < protocolType.length; i++) {
			command = "tshark -r " + fileName + " |grep '" + protocolType[i] + "' | wc -l";
			terminalCount = Integer.parseInt(execTerminalCmd(command).trim());
			hmap.put(protocolType[i], terminalCount);

		}
		hmap.put("total", Integer.parseInt(execTerminalCmd(command).trim()));

		return (hmap);
	}

}
