package com.mycompany.app.helper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.bind.DatatypeConverter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class JsonHelper {

	private static final Logger log = Logger.getLogger(JsonHelper.class);

	

	public static HttpResponse getHttpResponse(String Ip, String getRequest, String usrname, String pwd) {
		HttpClient httpClient = null;
		HttpGet httpget = null;
		String userNamePassword = null;
		httpClient = HttpClientBuilder.create().build();
		httpget = new HttpGet("http://" + Ip + getRequest);
		userNamePassword = usrname + ":" + pwd;
		String encoding = null;
		try {
			encoding = DatatypeConverter.printBase64Binary(userNamePassword.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		httpget.setHeader("Authorization", "Basic " + encoding);
		HttpResponse response = null;
		try {
			response = httpClient.execute(httpget);
		} catch (Exception e) {
			return null;
		}
		return response;
	}

	public static String readHttpResponse (HttpResponse response) {
		String responseStr = null;
		Integer status = response.getStatusLine().getStatusCode();
		HttpEntity entity = response.getEntity();
		if (entity != null) {
			try {
				responseStr = EntityUtils.toString(entity);
			} catch (Exception e) {
				responseStr = null;
			}
		}
		return responseStr;
	}

	public static HashMap getSwitchHttpResult(String Ip, String getRequest, String usrname, String pwd) {
		HashMap<String, Object> result = new HashMap();
		//First get the http response
		HttpResponse response = getHttpResponse(Ip, getRequest, usrname, pwd );
		if(response == null) {
			result.put("vReststatus", "Connection failure");
			result.put("data", null);
			result.put("vRestresult", null);
			result.put("status", null);
			return result;
		}
		String respStr = null;
		Integer status = response.getStatusLine().getStatusCode();
		respStr = readHttpResponse(response);
		if(respStr == null) {
			result.put("vReststatus", "No data failure");
			result.put("data", null);
			result.put("vRestresult", null);
			result.put("status", status);
			return result;
		}

		JSONArray data = null;
		JSONObject js = new JSONObject(respStr.toString());
		JSONObject res = js.getJSONObject("result");
		if (js.has("data")) {
			data = js.getJSONArray("data");
		}
		String vReststatus = res.getString("status");
		JSONArray vRestResult = res.getJSONArray("result");
		result.put("vReststatus", vReststatus);
		result.put("data", data);
		result.put("result", vRestResult);
		result.put("status", status);
		return result;
	}

	public static HashMap getBrowserStackHttpResult(String Ip, String getRequest, String usrname, String pwd) {
		HashMap<String, Object> result = new HashMap();
		//First get the http response
		HttpResponse response = getHttpResponse(Ip, getRequest, usrname, pwd );
		Integer status = response.getStatusLine().getStatusCode();
		if(response == null) {
			result.put("data", null);
			result.put("status", null);
			return result;
		}
		String respStr = null;
		respStr = readHttpResponse(response);
		if(respStr == null) {
			result.put("data", null);
			result.put("status", status);
			return result;
		}

		JSONObject data = null;
		JSONObject js = new JSONObject(respStr.toString());
		if (js.has("automation_session")) {
			data = js.getJSONObject("automation_session");
		}
		result.put("data", data);
		result.put("status", status);
		return result;
	}

	public JSONObject mergeJSONs(JSONObject jsonObj1, JSONObject jsonObj2) {
		JSONObject mergedJson = new JSONObject();
		JSONObject[] objs = new JSONObject[] { jsonObj1, jsonObj2 };
		for (JSONObject obj : objs) {
			Iterator it = obj.keys();
			while (it.hasNext()) {
				String key = (String)it.next();
				mergedJson.put(key, obj.get(key));
			}
		}
		return mergedJson;
	}

	public JSONArray mergeJsonArrays(ArrayList<JSONArray> jsonArrays){
		JSONArray mergedJsonArrays = new JSONArray();
		for (JSONArray tmpArray : jsonArrays) {
			for (int i = 0; i < tmpArray.length(); i++) {
				mergedJsonArrays.put(tmpArray.get(i));
			}
		}
		return mergedJsonArrays;
	}
}
